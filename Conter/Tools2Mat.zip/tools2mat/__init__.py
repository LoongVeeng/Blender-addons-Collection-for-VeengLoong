bl_info = {
    "name": "Tools2e",
    "blender": (2, 80, 0),
    "category": "Material",
    "location": "View3D > Sidebar > Edit Tab / Edit Mode Context Menu",
    "warning": "",
    "description": "Mesh modelling toolkit. Several tools to aid modelling",
    "doc_url": "{BLENDER_MANUAL_URL}/addons/mesh/looptools.html",
    "category": "Mesh",
}

import bpy
from . import material_panel

def register():
    material_panel.register()

def unregister():
    material_panel.unregister()

if __name__ == "__main__":
    register()
